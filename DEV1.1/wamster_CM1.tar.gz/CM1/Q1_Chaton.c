#include<stdio.h>
#include<stdlib.h>
int main(void){
  printf(" (\\_/) \n");
  printf("=(^.^)=\n");
  printf("(\")_(\")\n");
  return 0;
}
